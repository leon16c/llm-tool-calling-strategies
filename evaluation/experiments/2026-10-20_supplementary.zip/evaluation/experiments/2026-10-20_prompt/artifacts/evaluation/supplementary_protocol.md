# Supplementary experiment protocol

The protocol defines two experiments investigating sensitivity to completion guidance and sampling settings. It was specified on 2026-10-20 after inspection of the baseline results and before the corresponding model generations.

The original requests, tools, mocks, adapters and runners remain unchanged. `scripts/supplementary_session.py` is a separate recorder derived from the original recorder. It adds per-task generation settings and one V3 prompt subclass. Payloads, responses, source snapshots, runtime identities, run logs, hardware and a rotated sequential schedule are retained. No retry/fallback, no repair and no automatic stopping after a report. Failed generations due to transport/envelope errors abort the series rather than count as model failures. Existing sessions cannot be overwritten or restarted. Smoke sessions are excluded from measurement denominators.

## Prompt intervention

Thirty requests, one temperature-0/seed-0 run under each of two V3 prompts: sixty runs total. Alternate arm order by request. `original` uses the unchanged complete-plan prompt. `completion` adds V4's applicable no-repeat, required-report and default-format guidance, with a whole-plan instruction to stop the plan after `format_report`. It does not add a `finish` field or reveal the expected sequence. The exact added text is frozen in the recorder's `COMPLETION_GUIDANCE`. The treatment is a completion-guidance bundle, not an isolated test of one sentence. The original oracle gate and all validation remain active. Contemporary original-prompt controls address the runtime change from Ollama 0.40.1 in the primary matched series to observed 0.40.2 in this session.

Primary comparisons: runner acceptance, final-report presence in the proposed plan, tool-sequence agreement and argument projection agreement. Report paired changes by request. Do not infer semantic correctness from acceptance or sequence agreement. Historical observations remain separate.

## H2 sampling comparison

Thirty requests × five seeds × V2/V4 = 300 runs. Temperature 0.7; seed schedule 11, 22, 33, 44, 55, using the same seed for both variants within each request/repetition and throughout all generations of a run. Original prompts, runners, oracle gates and default budgets; sequential execution with rotating variant order. These repetitions vary the declared seed and measure sampling sensitivity for identical requests. They are not fixed-configuration repeatability trials and do not isolate temperature's causal effect relative to the older runtime.

Primary outcome: the existing normalized action-trace signature, retaining ordered tool names, statuses and arguments but omitting `data_id`. Compute distinct traces within each variant/request over five seeds; report thirty paired V2/V4 counts (higher/equal/lower). Supplement with complete ordered model-text signatures and parsed decisions/execution signatures including finish decisions and full references. Seeds/settings, timestamps, IDs and telemetry are not part of these behavior signatures. Report acceptance, status variation, error variation, exact argument agreement and prescribed-sequence completion separately. These are descriptive comparisons on thirty constructed inputs, not independent evidence from 150 tasks or measured business-output variability.

## Offline oracle sensitivity

`scripts/analyze_gate_sensitivity.py` verifies the original saved analysis, checks current source/schema hashes against the frozen snapshot, and reproduces all 300 original V3/V4 runs from recorded generations before evaluating the intervention. V3 removes only the complete-plan sequence check. V4 removes oracle next-tool and finish-length checks, retaining tool support, schema/dependency validation and a fixed eight-decision cap. A retained V4 generation is used only if its original prompt equals the prompt reconstructed from the replayed history. Exhausted recording or changed history yields unknown continuation. No model calls occur in offline replay. Technical termination, report reachability and semantic correctness remain separate.

## Integrity and analysis

Freeze this protocol, recorder, test and original source files before preparation. Verify each completed session against its manifest and schedule; check model/log settings against every submitted payload, prompt text against the appropriate adapter, hashes, response telemetry, run identity, ledger, coverage and runtime before computing outcomes. Unexpected missing or additional evidence fails verification. Preserve incomplete/aborted sessions as infrastructure evidence, without pooling them with complete series. New observations may change the interpretation of H1/H2; retain original observations and do not rewrite original semantic judgments.
