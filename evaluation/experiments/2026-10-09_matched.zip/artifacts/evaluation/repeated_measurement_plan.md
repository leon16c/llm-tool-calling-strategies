# Matched repeated-run measurement plan

Version 1, prepared 2026-10-09 before the new measurement series. Purpose: directly compare within-configuration action-trace repeatability for H2, using existing V2/V4 behavior; V3 adds coverage. No hypothesis outcome is assumed. This is a new recorded series, not a reconstruction of old runtime conditions.

## Treatment and coverage

- 30 original controlled requests, five repetitions each, V2/V3/V4: 450 scheduled runs, 150 per variant.
- Existing prompt builders, validators, oracle checks, mock tools and parsing behavior are reused unchanged. No repairs, retries, fallbacks or extra defaults are added to model instructions.
- All variants explicitly request the same installed `qwen2.5:7b-instruct` tag, temperature 0.0, seed 0, JSON mode, non-streaming `/api/generate` calls. No other options are newly forced; inherited model configuration and runtime residency are recorded and their limitations disclosed.
- The current observed runtime is Ollama 0.40.1; historical notes name 0.32.1/0.32.3. V2 is therefore rerun too. Do not pool new and old runs as one unchanged configuration. The current model digest is recorded by the preparation API, not inferred from the tag.
- Run serially. For each repetition and lexically sorted request, rotate variant order by `(repetition + request_index) mod 3`. Across 30 requests and five repetitions each variant occupies each position 50 times. This reduces fixed position imbalance; it does not eliminate cache, thermal or other time effects.
- No implicit warmup. A separate three-run smoke session for R002 verifies recording. Its outcomes are not measurement observations and do not justify prompt tuning. Model residency before/after each run documents loading state; it is not proof of identical cache contents.

## Preservation and preparation

The new controller is `evaluation/scripts/measurement_session.py`. It injects a recorded generation callable through the adapters' existing `generate` argument. It does not edit prototype source, prompts or old logs. New sessions are under `evaluation/experiments/`, outside the old log directories and historical audit inputs.

Preparation creates an exclusively new directory containing:

- `manifest.json`: scheduled tasks, execution order, runtime/model identity, Python/package versions, Git HEAD and working-tree status, source hashes, explicitly set options and known inherited settings.
- `artifacts/`: byte copies of source, schemas, request definitions, environment lock/configuration, recording controller/tests and this plan. Current source must still match these copies when executing.
- `runtime_prepared.json`: `/api/version`, selected model entry from `/api/tags`, complete `/api/show` response (including available template, system/model parameters) and `/api/ps` state.
- `hardware.json`: the supplied dated hardware inventory. Installed graphics adapters do not establish inference-device use; inspect runtime residency separately. Historical hardware is not reconstructed from this current inventory.

All required artifacts must exist and be inspected before starting. Current source and snapshot hashes, model digest/configuration and runtime version are checked before each run; runtime/model identity is checked afterwards as well. Detected drift aborts the series. A changed source or configuration requires a new identified session. These checks cannot detect every transient change between observations or unrecorded server environment change.

## Per-run recording

`started.json` exclusively marks session start; it prevents accidental restart/resumption. The manifest is the full denominator of scheduled tasks. `ledger.jsonl` records started, completed and error events with task identity and model-call count. Unstarted tasks remain identifiable from the manifest; an aborted series must not be presented as a complete 450-run experiment.

Each task has:

- `run_log.json`: unchanged runner schema and status/error classification.
- `runtime_before.json` and `runtime_after.json`: observed runtime/model configuration and residency.
- `model_calls/NNNN.request.json`: exact API payload and prompt, written before transport.
- `model_calls/NNNN.response.txt`: full HTTP response body before model-output parsing, retaining generated text, returned token/timing fields and context when provided.
- `model_calls/NNNN.event.json`: prompt/response hashes, wall-clock timestamps, monotonic durations, returned telemetry or transport/envelope error. Thus malformed generated content and successful V4 finish decisions remain inspectable even when they are not represented as tool calls.

`finished.json` records completed/aborted session state, scheduled/completed counts and any abort reason. No run is automatically retried. Transport/envelope failures stop the session even when an original runner catches them and emits a rejection; do not count them as pure model-quality failures. A model-generated invalid JSON response inside a valid API envelope remains an ordinary recorded first-pass rejection under the original runner.

## Timing and telemetry interpretation

Original `run_log.latency_ms` is retained but now includes recording overhead inside generation callbacks. Compare variants within this series and disclose instrumentation; do not mix these timings with historical uninstrumented averages.

- `http_response_elapsed_ms`: monotonic time from sending generation through receiving the response, excluding response-file persistence. It includes transport/runtime work, not merely token generation.
- Event `elapsed_ms`: additionally includes response persistence and envelope processing up to event creation; the event's own disk write is outside it.
- Ledger `recorded_run_elapsed_ms`: runner, output persistence and post-run runtime observation overhead.
- Ollama-returned durations and token counts are retained verbatim; record units from the API contract before interpreting them. Missing fields remain missing rather than being estimated from tool counts.
- `/api/ps` provides observed context/residency information where supported. Requested maximum model context and active context may differ. Server process environment and all effective generation defaults are not captured completely; do not claim stronger reproducibility than the available record supports.

## Analysis specified before measurement

Use the documented legacy normalized action signature to compare unique traces per request across five repetitions; report run-status variability separately. Report the fraction of requests with more than one trace, per-request signature counts and observed patterns for V2 versus V4. No observed difference would fail to support H2 under this configuration; low success alone is not evidence of variability. V3 is supplementary coverage.

Raw recorded finish decisions, error events and dependency checks support additional separately labelled analyses. Do not silently redefine the signature used for the original V2 reference. Report validated success, oracle agreement and any semantic review separately. Preserve selected-run and infrastructure-failure denominators and avoid treating repetitions as independent requests.

## Commands

Prepare the smoke session first, using a fresh path:

```powershell
.\prototype\.venv\Scripts\python.exe evaluation/scripts/measurement_session.py prepare --session evaluation/experiments/2026-10-09_smoke --hardware evaluation/experiments/hardware_2026-10-09.json --request R002 --repetitions 1 --purpose smoke
.\prototype\.venv\Scripts\python.exe evaluation/scripts/measurement_session.py run --session evaluation/experiments/2026-10-09_smoke
```

After checking the smoke evidence, prepare the measurement series without changing prompts or validators:

```powershell
.\prototype\.venv\Scripts\python.exe evaluation/scripts/measurement_session.py prepare --session evaluation/experiments/2026-10-09_matched --hardware evaluation/experiments/hardware_2026-10-09.json
.\prototype\.venv\Scripts\python.exe evaluation/scripts/measurement_session.py run --session evaluation/experiments/2026-10-09_matched
```

Preparation makes no generation call. A fresh session name is required if a directory already exists. Execution starts all scheduled tasks; `run` never silently resumes a partially completed directory.
